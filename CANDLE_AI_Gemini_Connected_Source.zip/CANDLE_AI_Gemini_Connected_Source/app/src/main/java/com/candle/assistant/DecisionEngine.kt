package com.candle.assistant

/**
 * Conservative decision layer. It combines the existing technical engine with
 * Supertrend confirmation. Estimated OHLC footprint is context only and never
 * increases the decision confidence or creates a trade signal.
 */
object DecisionEngine {
    data class Result(
        val title: String,
        val confidence: Int,
        val reasons: List<String>,
        val status: String,
        val colorCode: Int
    )

    fun evaluate(
        technical: Output,
        supertrendDirection: Int,
        flow: AdvancedMarketAnalysis.FlowAnalysis,
        flowIsEstimated: Boolean
    ): Result {
        val reasons = ArrayList<String>()
        if (technical.kind == Signal.NOGO) {
            return Result(
                "بيانات غير كافية", 0,
                listOf(technical.block.ifBlank { "تعذر التحقق من جودة الشموع." }),
                "لا توجد إشارة", 0
            )
        }

        if (technical.kind != Signal.SIGNAL || technical.side == 0) {
            reasons.add(technical.block.ifBlank { "المؤشرات الفنية لم تصل إلى شروط الإشارة." })
            reasons.add("توافق المؤشرات: ${technical.agree}، والمتعارض: ${technical.against}.")
            if (supertrendDirection == 0) reasons.add("اتجاه Supertrend غير متاح.")
            return Result("انتظار", technical.conf.coerceIn(0, 59), reasons, "الإشارات غير حاسمة", 0)
        }

        val signalSide = technical.side
        val trendAgrees = supertrendDirection == signalSide
        if (supertrendDirection == 0) {
            reasons.add("Supertrend غير متاح؛ لا يمكن تأكيد الاتجاه.")
            reasons.add("إشارة المحرك الفني وحدها لا تكفي لإظهار قرار اتجاهي.")
            return Result("انتظار", technical.conf.coerceIn(0, 59), reasons, "تأكيد الاتجاه ناقص", 0)
        }
        if (!trendAgrees) {
            reasons.add("تعارض بين المحرك الفني وSupertrend.")
            reasons.add("المحرك الفني: ${if (signalSide > 0) "صاعد" else "هابط"}؛ Supertrend: ${if (supertrendDirection > 0) "صاعد" else "هابط"}.")
            return Result("انتظار", technical.conf.coerceIn(0, 59), reasons, "تعارض مؤشرات", 0)
        }

        reasons.add("المحرك الفني وSupertrend متفقان على الاتجاه ${if (signalSide > 0) "الصاعد" else "الهابط"}.")
        reasons.add("توافق المؤشرات: ${technical.agree}، والمتعارض: ${technical.against}.")
        reasons.add(flow.trendAgreement)
        if (flowIsEstimated) {
            reasons.add("Footprint تقديري من OHLC؛ استُخدم كسياق وصفي فقط ولم يرفع درجة الثقة.")
        } else {
            reasons.add("بيانات Footprint من مصدر صفقات؛ استُخدمت كسياق مساعد وليست ضمانًا.")
        }

        val penalty = if (technical.against > 1) 8 else 0
        val confidence = (technical.conf.coerceIn(0, 85) - penalty).coerceIn(0, 85)
        if (confidence < 60) {
            reasons.add("درجة التوافق المعدلة أقل من حد العرض الاتجاهي؛ الأفضل الانتظار.")
            return Result("انتظار", confidence, reasons, "توافق غير كافٍ", 0)
        }
        return Result(
            if (signalSide > 0) "اتجاه صاعد" else "اتجاه هابط",
            confidence,
            reasons,
            "توافق فني وليس احتمال ربح أو توصية مضمونة",
            if (signalSide > 0) 1 else -1
        )
    }
}
