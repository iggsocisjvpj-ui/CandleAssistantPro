package com.candle.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import java.util.Locale
import kotlin.math.max

/** Visual price ladder for estimated or real footprint levels. */
class FootprintChartView(context: Context, private val levels: List<AdvancedMarketAnalysis.LevelFlow>, private val poc: Double?) : View(context) {
    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(225, 233, 245); textSize = dp(11f) }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(170, 185, 207); textSize = dp(9f) }
    private val buyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(35, 165, 120) }
    private val sellPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(205, 75, 86) }
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(54, 69, 91); strokeWidth = dp(1f) }
    private val pocPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(235, 180, 70) }
    private val rowBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(31, 44, 64) }
    private val fmt = { v: Double -> String.format(Locale.US, "%.2f", v) }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val rows = levels.takeLast(10)
        val h = dp(48f + rows.size * 35f).toInt()
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), resolveSize(h, heightMeasureSpec))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val rows = levels.takeLast(10).asReversed()
        val w = width.toFloat()
        val pad = dp(10f)
        val rowH = dp(35f)
        val headerY = dp(17f)
        val priceX = w - pad
        val deltaX = pad
        val sellStart = w * 0.37f
        val buyStart = w * 0.62f
        val barMax = w * 0.22f
        text.textSize = dp(10f)
        text.color = Color.rgb(235, 180, 80)
        text.textAlign = Paint.Align.RIGHT
        canvas.drawText("السعر", priceX, headerY, text)
        text.textAlign = Paint.Align.CENTER
        canvas.drawText("شراء", buyStart + barMax / 2f, headerY, text)
        canvas.drawText("بيع", sellStart + barMax / 2f, headerY, text)
        text.textAlign = Paint.Align.LEFT
        canvas.drawText("Δ", deltaX, headerY, text)
        val maxValue = max(1.0, rows.maxOfOrNull { max(it.buy, it.sell) } ?: 1.0)
        rows.forEachIndexed { index, level ->
            val top = dp(25f) + index * rowH
            val baseline = top + dp(22f)
            val isPoc = poc != null && kotlin.math.abs(level.price - poc) < 1e-8
            if (isPoc) canvas.drawRoundRect(RectF(pad, top, w - pad, top + rowH - dp(2f)), dp(6f), dp(6f), rowBg)
            canvas.drawLine(pad, top + rowH - dp(1f), w - pad, top + rowH - dp(1f), grid)
            val buyWidth = (level.buy / maxValue * barMax).toFloat()
            val sellWidth = (level.sell / maxValue * barMax).toFloat()
            canvas.drawRoundRect(RectF(buyStart, top + dp(7f), buyStart + max(dp(2f), buyWidth), top + dp(26f)), dp(3f), dp(3f), buyPaint)
            canvas.drawRoundRect(RectF(sellStart, top + dp(7f), sellStart + max(dp(2f), sellWidth), top + dp(26f)), dp(3f), dp(3f), sellPaint)
            small.textAlign = Paint.Align.RIGHT
            small.color = if (isPoc) Color.rgb(255, 205, 95) else Color.rgb(205, 216, 232)
            canvas.drawText(fmt(level.price), priceX, baseline, small)
            small.textAlign = Paint.Align.LEFT
            small.color = if (level.delta >= 0) Color.rgb(75, 205, 155) else Color.rgb(245, 115, 120)
            canvas.drawText(fmt(level.delta), deltaX, baseline, small)
            small.textAlign = Paint.Align.CENTER
            small.color = Color.WHITE
            canvas.drawText(fmt(level.buy), buyStart + barMax / 2f, baseline, small)
            canvas.drawText(fmt(level.sell), sellStart + barMax / 2f, baseline, small)
            if (isPoc) {
                pocPaint.style = Paint.Style.STROKE
                pocPaint.strokeWidth = dp(1.5f)
                canvas.drawRoundRect(RectF(pad, top, w - pad, top + rowH - dp(2f)), dp(6f), dp(6f), pocPaint)
                pocPaint.style = Paint.Style.FILL
            }
        }
    }
}
