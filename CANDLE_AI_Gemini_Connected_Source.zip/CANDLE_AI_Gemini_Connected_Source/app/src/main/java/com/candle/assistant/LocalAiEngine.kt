package com.candle.assistant

import android.content.Context

/**
 * المحرك المحلي: يستخدم محرك الشموع والمؤشرات الموجودين في التطبيق.
 * لا يحتاج إلى إنترنت ولا ينفذ أي صفقة.
 */
object LocalAiEngine {
    fun analyze(
        context: Context,
        candles: List<Candle>,
        timeframeSeconds: Int,
        minConfidence: Int = 58,
        sensitivity: Int = 3
    ): Output {
        val safeTimeframe = timeframeSeconds.coerceIn(1, 86400)
        val regime = Signal.regimeOf(candles)
        val key = "${safeTimeframe}_$regime"
        val weights = Learner.weights(context, key)
        val bias = Learner.bias(context, key)
        return Signal.compute(
            candles,
            minConfidence.coerceIn(50, 95),
            sensitivity.coerceIn(1, 5),
            weights,
            bias
        )
    }

    fun toAiAnalysis(output: Output): AiAnalysis {
        val direction = when {
            output.kind == Signal.NOGO -> "بيانات غير كافية"
            output.kind == Signal.WAIT -> "انتظار"
            output.side > 0 -> "صاعد / شراء محتمل"
            output.side < 0 -> "هابط / بيع محتمل"
            else -> "انتظار"
        }
        val reason = listOf(output.why, output.block, output.info)
            .filter { it.isNotBlank() }
            .joinToString("\n")
        return AiAnalysis(
            direction = direction,
            confidence = output.conf.coerceIn(0, 100),
            explanation = reason.ifBlank { "لم يقدم المحرك المحلي تفسيرًا إضافيًا." },
            source = "تحليل محلي: المؤشرات والشموع الموجودة في التطبيق",
            cloudUsed = false
        )
    }
}
