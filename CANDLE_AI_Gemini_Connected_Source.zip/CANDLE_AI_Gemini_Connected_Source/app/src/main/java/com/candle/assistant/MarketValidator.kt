package com.candle.assistant

import kotlin.math.abs

/** التحقق من صحة بيانات الشموع المقروءة قبل تحليلها. */
object MarketValidator {
    /** null = القراءة موثوقة، وإلا سبب الرفض */
    fun check(c: List<Candle>): String? {
        if (c.size < 12) return "عدد الشموع المقروءة ${c.size} فقط"
        var bad = 0
        for (x in c) {
            if (x.high < maxOf(x.open, x.close) - 1e-9 || x.low > minOf(x.open, x.close) + 1e-9) bad++
        }
        if (bad > c.size * 0.1) return "شموع بهندسة غير منطقية"
        val flat = c.count { it.high - it.low < 1e-9 }
        if (flat > c.size * 0.5) return "شموع بلا مدى سعري"
        val atr = Ind.atr(c, 14).coerceAtLeast(1e-6)
        val gaps = (1 until c.size).map { abs(c[it].open - c[it - 1].close) / atr }.sorted()
        if (gaps[gaps.size / 2] > 0.8) return "الشموع غير متصلة ببعضها (قراءة مشوشة)"
        return null
    }
}
